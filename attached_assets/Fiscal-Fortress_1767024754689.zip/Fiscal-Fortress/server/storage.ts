import { db } from "./db";
import {
  accounts, envelopes, transactions, debts, taxEntries,
  type Account, type InsertAccount,
  type Envelope, type InsertEnvelope,
  type Transaction, type InsertTransaction,
  type Debt, type InsertDebt,
  type TaxEntry, type InsertTaxEntry
} from "@shared/schema";
import { eq, sum } from "drizzle-orm";

export interface IStorage {
  // Accounts
  getAccounts(userId: string): Promise<Account[]>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, updates: Partial<InsertAccount>): Promise<Account>;
  
  // Envelopes
  getEnvelopes(userId: string): Promise<Envelope[]>;
  createEnvelope(envelope: InsertEnvelope): Promise<Envelope>;
  updateEnvelope(id: number, updates: Partial<InsertEnvelope>): Promise<Envelope>;
  
  // Transactions
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Debts
  getDebts(userId: string): Promise<Debt[]>;
  createDebt(debt: InsertDebt): Promise<Debt>;
  
  // Taxes
  getTaxEntries(userId: string): Promise<TaxEntry[]>;
  createTaxEntry(entry: InsertTaxEntry): Promise<TaxEntry>;
  
  // Financial Snapshot
  getFinancialSnapshot(userId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  async getAccounts(userId: string): Promise<Account[]> {
    return await db.select().from(accounts).where(eq(accounts.userId, userId));
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const [account] = await db.insert(accounts).values(insertAccount).returning();
    return account;
  }

  async updateAccount(id: number, updates: Partial<InsertAccount>): Promise<Account> {
    const [updated] = await db.update(accounts).set(updates).where(eq(accounts.id, id)).returning();
    return updated;
  }

  async getEnvelopes(userId: string): Promise<Envelope[]> {
    return await db.select().from(envelopes).where(eq(envelopes.userId, userId));
  }

  async createEnvelope(insertEnvelope: InsertEnvelope): Promise<Envelope> {
    const [envelope] = await db.insert(envelopes).values(insertEnvelope).returning();
    return envelope;
  }

  async updateEnvelope(id: number, updates: Partial<InsertEnvelope>): Promise<Envelope> {
    const [updated] = await db.update(envelopes).set(updates).where(eq(envelopes.id, id)).returning();
    return updated;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(insertTransaction).returning();
    
    // Update account balance
    if (insertTransaction.accountId) {
      const account = await db.query.accounts.findFirst({
        where: eq(accounts.id, insertTransaction.accountId)
      });
      if (account) {
        let newBalance = Number(account.balance);
        if (insertTransaction.type === 'income') {
          newBalance += Number(insertTransaction.amount);
        } else {
          newBalance -= Number(insertTransaction.amount);
        }
        await this.updateAccount(account.id, { balance: newBalance.toString() });
      }
    }

    // Update envelope balance
    if (insertTransaction.envelopeId) {
      const envelope = await db.query.envelopes.findFirst({
        where: eq(envelopes.id, insertTransaction.envelopeId)
      });
      if (envelope) {
        let newBalance = Number(envelope.currentBalance);
        if (insertTransaction.type === 'income') { // Funding the envelope
          newBalance += Number(insertTransaction.amount);
        } else { // Spending from envelope
          newBalance -= Number(insertTransaction.amount);
        }
        await this.updateEnvelope(envelope.id, { currentBalance: newBalance.toString() });
      }
    }

    return transaction;
  }

  async getDebts(userId: string): Promise<Debt[]> {
    return await db.select().from(debts).where(eq(debts.userId, userId));
  }

  async createDebt(insertDebt: InsertDebt): Promise<Debt> {
    const [debt] = await db.insert(debts).values(insertDebt).returning();
    return debt;
  }

  async getTaxEntries(userId: string): Promise<TaxEntry[]> {
    return await db.select().from(taxEntries).where(eq(taxEntries.userId, userId));
  }

  async createTaxEntry(insertEntry: InsertTaxEntry): Promise<TaxEntry> {
    const [entry] = await db.insert(taxEntries).values(insertEntry).returning();
    return entry;
  }

  async getFinancialSnapshot(userId: string): Promise<any> {
    const [
      userAccounts,
      userEnvelopes,
      userDebts
    ] = await Promise.all([
      this.getAccounts(userId),
      this.getEnvelopes(userId),
      this.getDebts(userId)
    ]);

    const spendingAccount = userAccounts.find(a => a.name.toLowerCase().includes('spending')) || userAccounts[0];
    const totalDebt = userDebts.reduce((sum, d) => sum + Number(d.totalAmount), 0);
    const strictEnvelopes = userEnvelopes.filter(e => e.isStrict);

    return {
      spendingBalance: spendingAccount ? Number(spendingAccount.balance) : 0,
      totalDebt,
      envelopes: userEnvelopes,
      strictRequirements: strictEnvelopes.map(e => ({
        name: e.name,
        target: e.targetAmount,
        current: e.currentBalance,
        due: e.dueDate
      }))
    };
  }
}

export const storage = new DatabaseStorage();
