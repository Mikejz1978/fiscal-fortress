import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);
  registerImageRoutes(app);

  // Protected Routes Middleware
  // app.use('/api', isAuthenticated); // Apply to all /api routes? No, login is /api/login

  // === ACCOUNTS ===
  app.get(api.accounts.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    let accountsList = await storage.getAccounts(userId);
    
    // Auto-seed if empty
    if (accountsList.length === 0) {
      console.log("Seeding data for new user:", userId);
      await storage.createAccount({ userId, name: "Bills Account", type: "checking", balance: "1500", isMain: false });
      await storage.createAccount({ userId, name: "Spending Account", type: "checking", balance: "200", isMain: true });
      await storage.createAccount({ userId, name: "Savings Account", type: "savings", balance: "50", isMain: false });
      
      await storage.createEnvelope({ userId, name: "Rent", targetAmount: "1200", currentBalance: "1000", dueDate: 1, isStrict: true, isBiWeekly: false });
      await storage.createEnvelope({ userId, name: "Brady (Employee)", targetAmount: "300", currentBalance: "300", dueDate: 15, isStrict: true, isBiWeekly: false });
      await storage.createEnvelope({ userId, name: "Groceries", targetAmount: "400", currentBalance: "50", dueDate: 30, isStrict: false, isBiWeekly: false });
      
      await storage.createDebt({ userId, name: "Credit Card", totalAmount: "5000", interestRate: "18.99", minimumPayment: "100", dueDate: 20 });
      await storage.createDebt({ userId, name: "Car Loan", totalAmount: "12000", interestRate: "5.5", minimumPayment: "300", dueDate: 15 }); // Bi-weekly logic handled in frontend/logic
      
      accountsList = await storage.getAccounts(userId);
    }
    
    res.json(accountsList);
  });

  app.post(api.accounts.create.path, isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const input = api.accounts.create.input.parse({ ...req.body, userId });
      const account = await storage.createAccount(input);
      res.status(201).json(account);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.put(api.accounts.update.path, isAuthenticated, async (req, res) => {
    const account = await storage.updateAccount(Number(req.params.id), req.body);
    res.json(account);
  });

  // === ENVELOPES ===
  app.get(api.envelopes.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const envelopes = await storage.getEnvelopes(userId);
    res.json(envelopes);
  });

  app.post(api.envelopes.create.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const input = api.envelopes.create.input.parse({ ...req.body, userId });
    const envelope = await storage.createEnvelope(input);
    res.status(201).json(envelope);
  });

  app.put(api.envelopes.update.path, isAuthenticated, async (req, res) => {
    const envelope = await storage.updateEnvelope(Number(req.params.id), req.body);
    res.json(envelope);
  });

  // === TRANSACTIONS ===
  app.get(api.transactions.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const transactions = await storage.getTransactions(userId);
    res.json(transactions);
  });

  app.post(api.transactions.create.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const input = api.transactions.create.input.parse({ ...req.body, userId });
    const transaction = await storage.createTransaction(input);
    res.status(201).json(transaction);
  });

  // === DEBTS ===
  app.get(api.debts.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const debts = await storage.getDebts(userId);
    res.json(debts);
  });

  app.post(api.debts.create.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const input = api.debts.create.input.parse({ ...req.body, userId });
    const debt = await storage.createDebt(input);
    res.status(201).json(debt);
  });

  // === TAXES ===
  app.get(api.taxes.list.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const taxes = await storage.getTaxEntries(userId);
    res.json(taxes);
  });

  app.post(api.taxes.create.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const input = api.taxes.create.input.parse({ ...req.body, userId });
    const tax = await storage.createTaxEntry(input);
    res.status(201).json(tax);
  });

  // === ADVISOR ===
  app.post(api.advisor.chat.path, isAuthenticated, async (req, res) => {
    const userId = (req.user as any).claims.sub;
    const userMessage = req.body.message;
    
    // Get Context
    const snapshot = await storage.getFinancialSnapshot(userId);
    
    const systemPrompt = `
      You are a strict, no-nonsense financial advisor designed to get the user out of debt and keep them strictly on budget.
      
      User's Financial Snapshot:
      - Spending Money Available: $${snapshot.spendingBalance}
      - Total Debt: $${snapshot.totalDebt}
      
      Strict Envelopes (MUST BE PAID):
      ${snapshot.strictRequirements.map((e: any) => `- ${e.name}: Need $${e.target}, Have $${e.current}. Due day: ${e.due}`).join('\n')}
      
      Rules:
      1. If the user asks to buy something, check if they have enough in "Spending Money".
      2. If "Spending Money" is low, or if Strict Envelopes are underfunded, tell them NO firmly.
      3. Remind them of their debt goals.
      4. Be encouraging but strict. "Strict enforcement".
      
      User Question: "${userMessage}"
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "system", content: systemPrompt }],
        max_completion_tokens: 500,
      });

      const aiResponse = response.choices[0].message.content || "I couldn't process that request.";
      res.json({ response: aiResponse });
    } catch (error) {
      console.error("AI Error:", error);
      res.status(500).json({ message: "AI Advisor is currently unavailable." });
    }
  });

  return httpServer;
}
