import { z } from 'zod';
import { 
  insertAccountSchema, 
  insertEnvelopeSchema, 
  insertTransactionSchema, 
  insertDebtSchema, 
  insertTaxEntrySchema,
  accounts,
  envelopes,
  transactions,
  debts,
  taxEntries
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  accounts: {
    list: {
      method: 'GET' as const,
      path: '/api/accounts',
      responses: {
        200: z.array(z.custom<typeof accounts.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/accounts',
      input: insertAccountSchema,
      responses: {
        201: z.custom<typeof accounts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/accounts/:id',
      input: insertAccountSchema.partial(),
      responses: {
        200: z.custom<typeof accounts.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  envelopes: {
    list: {
      method: 'GET' as const,
      path: '/api/envelopes',
      responses: {
        200: z.array(z.custom<typeof envelopes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/envelopes',
      input: insertEnvelopeSchema,
      responses: {
        201: z.custom<typeof envelopes.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/envelopes/:id',
      input: insertEnvelopeSchema.partial(),
      responses: {
        200: z.custom<typeof envelopes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  transactions: {
    list: {
      method: 'GET' as const,
      path: '/api/transactions',
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/transactions',
      input: insertTransactionSchema,
      responses: {
        201: z.custom<typeof transactions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  debts: {
    list: {
      method: 'GET' as const,
      path: '/api/debts',
      responses: {
        200: z.array(z.custom<typeof debts.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/debts',
      input: insertDebtSchema,
      responses: {
        201: z.custom<typeof debts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  taxes: {
    list: {
      method: 'GET' as const,
      path: '/api/taxes',
      responses: {
        200: z.array(z.custom<typeof taxEntries.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/taxes',
      input: insertTaxEntrySchema,
      responses: {
        201: z.custom<typeof taxEntries.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  advisor: {
    chat: {
      method: 'POST' as const,
      path: '/api/advisor/chat',
      input: z.object({
        message: z.string(),
      }),
      responses: {
        200: z.object({
          response: z.string(),
        }),
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
