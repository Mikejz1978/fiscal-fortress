import { pgTable, text, serial, integer, boolean, timestamp, numeric, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth"; // Import users from auth schema

// === ACCOUNTS ===
// Virtual representation of real bank accounts (Bills, Spending, Savings)
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Links to auth.users.id
  name: text("name").notNull(), // e.g., "Bills Account", "Spending Account"
  type: text("type").notNull(), // 'checking', 'savings'
  balance: numeric("balance").notNull().default("0"),
  isMain: boolean("is_main").default(false), // The main account for income
});

// === ENVELOPES ===
// Budget categories (Rent, Brady, Groceries)
export const envelopes = pgTable("envelopes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(), // e.g., "Brady", "Rent"
  targetAmount: numeric("target_amount").notNull(), // Monthly need
  currentBalance: numeric("current_balance").notNull().default("0"),
  dueDate: integer("due_date"), // Day of month (1-31)
  isStrict: boolean("is_strict").default(false), // "Not negotiable"
  isBiWeekly: boolean("is_bi_weekly").default(false), // For loan hacks
});

// === TRANSACTIONS ===
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  accountId: integer("account_id").references(() => accounts.id),
  envelopeId: integer("envelope_id").references(() => envelopes.id),
  amount: numeric("amount").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").defaultNow(),
  type: text("type").notNull(), // 'income', 'expense', 'transfer'
});

// === DEBTS ===
export const debts = pgTable("debts", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(), // e.g., "Credit Card 1"
  totalAmount: numeric("total_amount").notNull(),
  interestRate: numeric("interest_rate").notNull(),
  minimumPayment: numeric("minimum_payment").notNull(),
  dueDate: integer("due_date"),
});

// === TAX ENTRIES ===
export const taxEntries = pgTable("tax_entries", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  description: text("description").notNull(),
  amount: numeric("amount").notNull(),
  type: text("type").notNull(), // 'income', 'write_off', 'payment'
  date: timestamp("date").defaultNow(),
  category: text("category"), // e.g., 'business_expense', 'charity'
});

// === RELATIONS ===
export const accountsRelations = relations(accounts, ({ many }) => ({
  transactions: many(transactions),
}));

export const envelopesRelations = relations(envelopes, ({ many }) => ({
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  account: one(accounts, {
    fields: [transactions.accountId],
    references: [accounts.id],
  }),
  envelope: one(envelopes, {
    fields: [transactions.envelopeId],
    references: [envelopes.id],
  }),
}));

// === ZOD SCHEMAS ===
export const insertAccountSchema = createInsertSchema(accounts).omit({ id: true });
export const insertEnvelopeSchema = createInsertSchema(envelopes).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, date: true });
export const insertDebtSchema = createInsertSchema(debts).omit({ id: true });
export const insertTaxEntrySchema = createInsertSchema(taxEntries).omit({ id: true, date: true });

// === EXPLICIT TYPES ===
export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;

export type Envelope = typeof envelopes.$inferSelect;
export type InsertEnvelope = z.infer<typeof insertEnvelopeSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Debt = typeof debts.$inferSelect;
export type InsertDebt = z.infer<typeof insertDebtSchema>;

export type TaxEntry = typeof taxEntries.$inferSelect;
export type InsertTaxEntry = z.infer<typeof insertTaxEntrySchema>;

// Export auth models so they are included in migrations
export * from "./models/auth";
export * from "./models/chat";
