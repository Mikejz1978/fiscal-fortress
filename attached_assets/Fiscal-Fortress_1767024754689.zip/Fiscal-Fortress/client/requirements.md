## Packages
recharts | For visualizing net worth, debt payoff, and budget utilization
framer-motion | For smooth page transitions and micro-interactions
date-fns | For formatting transaction dates and due dates
clsx | For conditional class names (utility)
tailwind-merge | For merging tailwind classes safely (utility)

## Notes
- Tailwind config needs to extend font families for 'sans' (Inter/DM Sans) and 'display' (Outfit/Space Grotesk)
- Auth is handled via /api/login and /api/logout endpoints
- API requests use `credentials: "include"` for session cookie handling
