import { Layout } from "@/components/Layout";
import { useEnvelopes, useCreateEnvelope } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Lock, Calendar, RefreshCcw } from "lucide-react";
import { useState } from "react";
import { insertEnvelopeSchema } from "@shared/schema";
import { cn } from "@/lib/utils";

const formSchema = insertEnvelopeSchema.extend({
  targetAmount: z.coerce.number(),
  currentBalance: z.coerce.number(),
  dueDate: z.coerce.number().optional(),
});

export default function Envelopes() {
  const { data: envelopes, isLoading } = useEnvelopes();
  const createEnvelope = useCreateEnvelope();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      targetAmount: 0,
      currentBalance: 0,
      isStrict: false,
      isBiWeekly: false,
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    const submissionData = { ...data, userId: "current" }; 
    createEnvelope.mutate(submissionData as any, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Envelopes</h2>
          <p className="text-muted-foreground">Budget strict bills and discretionary spending.</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="w-5 h-5 mr-2" />
              New Envelope
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Create Envelope</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" {...form.register("name")} placeholder="e.g. Rent, Groceries" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="targetAmount">Monthly Target</Label>
                  <Input id="targetAmount" type="number" {...form.register("targetAmount")} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currentBalance">Current Balance</Label>
                  <Input id="currentBalance" type="number" {...form.register("currentBalance")} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date (Day of Month)</Label>
                <Input id="dueDate" type="number" min="1" max="31" {...form.register("dueDate")} placeholder="e.g. 15" />
              </div>

              <div className="flex flex-col gap-3 pt-2">
                <div className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    id="isStrict" 
                    className="rounded border-gray-600 bg-gray-700 text-primary focus:ring-primary"
                    {...form.register("isStrict")} 
                  />
                  <Label htmlFor="isStrict" className="font-medium text-amber-400">Strict (Non-negotiable bill)</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    id="isBiWeekly" 
                    className="rounded border-gray-600 bg-gray-700 text-primary focus:ring-primary"
                    {...form.register("isBiWeekly")} 
                  />
                  <Label htmlFor="isBiWeekly">Bi-Weekly Funding (Loan Hack)</Label>
                </div>
              </div>

              <div className="pt-4">
                <Button type="submit" className="w-full" disabled={createEnvelope.isPending}>
                  {createEnvelope.isPending ? "Creating..." : "Create Envelope"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {envelopes?.map((envelope) => {
          const progress = (Number(envelope.currentBalance) / Number(envelope.targetAmount)) * 100;
          return (
            <Card key={envelope.id} className={cn(
              "bg-card border-border hover:border-primary/50 transition-all",
              envelope.isStrict && "border-l-4 border-l-amber-500"
            )}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  {envelope.name}
                </CardTitle>
                <div className="flex gap-2">
                  {envelope.isStrict && <Lock className="w-4 h-4 text-amber-500" />}
                  {envelope.isBiWeekly && <RefreshCcw className="w-4 h-4 text-blue-400" />}
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-2xl font-bold">${Number(envelope.currentBalance).toFixed(0)}</span>
                  <span className="text-sm text-muted-foreground">of ${Number(envelope.targetAmount).toFixed(0)}</span>
                </div>
                
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden mb-4">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      progress >= 100 ? "bg-emerald-500" : (envelope.isStrict ? "bg-amber-500" : "bg-primary")
                    )}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </div>

                {envelope.dueDate && (
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3 mr-1" />
                    Due on the {envelope.dueDate}th
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </Layout>
  );
}
