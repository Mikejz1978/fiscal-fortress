import { Layout } from "@/components/Layout";
import { useDebts, useCreateDebt } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, TrendingDown, CalendarClock } from "lucide-react";
import { useState } from "react";
import { insertDebtSchema } from "@shared/schema";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";

const formSchema = insertDebtSchema.extend({
  totalAmount: z.coerce.number(),
  interestRate: z.coerce.number(),
  minimumPayment: z.coerce.number(),
  dueDate: z.coerce.number().optional(),
});

export default function Debts() {
  const { data: debts, isLoading } = useDebts();
  const createDebt = useCreateDebt();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      totalAmount: 0,
      interestRate: 0,
      minimumPayment: 0,
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    const submissionData = { ...data, userId: "current" }; 
    createDebt.mutate(submissionData as any, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  const totalDebt = debts?.reduce((sum, d) => sum + Number(d.totalAmount), 0) || 0;
  const chartData = debts?.map(d => ({
    name: d.name,
    amount: Number(d.totalAmount)
  })) || [];

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Debt Crusher</h2>
          <p className="text-muted-foreground">Visualize your path to freedom.</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="destructive" className="shadow-lg shadow-red-900/20">
              <Plus className="w-5 h-5 mr-2" />
              Add Liability
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Add Debt</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" {...form.register("name")} placeholder="e.g. Visa Card" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="totalAmount">Total Owed</Label>
                  <Input id="totalAmount" type="number" {...form.register("totalAmount")} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Interest Rate (%)</Label>
                  <Input id="interestRate" type="number" step="0.1" {...form.register("interestRate")} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minimumPayment">Min Payment</Label>
                  <Input id="minimumPayment" type="number" {...form.register("minimumPayment")} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Day</Label>
                  <Input id="dueDate" type="number" max="31" {...form.register("dueDate")} />
                </div>
              </div>

              <div className="pt-4">
                <Button type="submit" variant="destructive" className="w-full" disabled={createDebt.isPending}>
                  {createDebt.isPending ? "Adding..." : "Add Debt"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Summary Card */}
        <Card className="bg-gradient-to-br from-red-950/40 to-card border-red-900/30">
          <CardHeader>
            <CardTitle className="text-red-200">Total Liability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-display font-bold text-white mb-2">
              ${totalDebt.toFixed(2)}
            </div>
            <p className="text-sm text-red-300/70">
              Paying minimums only extends the pain. Attack the highest interest first.
            </p>
          </CardContent>
        </Card>

        {/* Chart */}
        <Card className="lg:col-span-2 bg-card/50 border-border">
          <CardHeader>
            <CardTitle>Debt Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="amount" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* List of Debts */}
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {debts?.map((debt) => (
            <Card key={debt.id} className="bg-card border-border hover:border-red-500/30 transition-all">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-medium">{debt.name}</CardTitle>
                <div className="bg-red-500/10 text-red-400 px-2 py-1 rounded text-xs font-bold">
                  {Number(debt.interestRate)}% APR
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <span className="text-2xl font-bold">${Number(debt.totalAmount).toFixed(2)}</span>
                    <p className="text-xs text-muted-foreground mt-1">Outstanding Balance</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground bg-secondary/50 p-3 rounded-lg">
                  <CalendarClock className="w-4 h-4" />
                  <span>Min Payment: <span className="text-foreground font-medium">${Number(debt.minimumPayment)}</span></span>
                  {debt.dueDate && <span className="ml-auto">Due: {debt.dueDate}th</span>}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}
