import { Layout } from "@/components/Layout";
import { MetricCard } from "@/components/MetricCard";
import { useAccounts, useEnvelopes, useDebts, useTransactions } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, AlertCircle, TrendingUp, ShieldCheck, Wallet, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function Home() {
  const { data: accounts, isLoading: accountsLoading } = useAccounts();
  const { data: envelopes, isLoading: envelopesLoading } = useEnvelopes();
  const { data: debts, isLoading: debtsLoading } = useDebts();
  const { data: transactions, isLoading: txLoading } = useTransactions();

  const isLoading = accountsLoading || envelopesLoading || debtsLoading || txLoading;

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <Skeleton className="h-10 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-2xl" />)}
          </div>
          <Skeleton className="h-96 rounded-2xl" />
        </div>
      </Layout>
    );
  }

  // Calculations
  const totalBalance = accounts?.reduce((sum, acc) => sum + Number(acc.balance), 0) || 0;
  const mainAccount = accounts?.find(a => a.isMain);
  const spendingAccount = accounts?.find(a => a.type === 'checking' && !a.isMain);
  
  const totalDebt = debts?.reduce((sum, d) => sum + Number(d.totalAmount), 0) || 0;
  const strictEnvelopes = envelopes?.filter(e => e.isStrict) || [];
  const monthlyBills = strictEnvelopes.reduce((sum, e) => sum + Number(e.targetAmount), 0);
  
  // Safe to Spend = Spending Account Balance (if separate) or derived from Main
  const safeToSpend = spendingAccount ? Number(spendingAccount.balance) : 0;

  const recentTransactions = transactions?.slice(0, 5) || [];

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Financial Fortress</h2>
          <p className="text-muted-foreground">Welcome back. Your perimeter is secure.</p>
        </div>
        <Link href="/advisor">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-lg shadow-primary/20">
            <ShieldCheck className="w-5 h-5 mr-2" />
            Ask Advisor
          </Button>
        </Link>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Safe to Spend"
          value={`$${safeToSpend.toFixed(2)}`}
          icon={<Wallet className="w-5 h-5" />}
          subtitle="Discretionary Funds"
          trend="neutral"
          className="border-primary/20 bg-primary/5"
        />
        <MetricCard
          title="Total Liquidity"
          value={`$${totalBalance.toFixed(2)}`}
          icon={<DollarSign className="w-5 h-5" />}
          subtitle="All Accounts"
        />
        <MetricCard
          title="Debt Load"
          value={`$${totalDebt.toFixed(2)}`}
          icon={<AlertCircle className="w-5 h-5" />}
          subtitle="Target: $0.00"
          className={totalDebt > 0 ? "border-red-500/20 bg-red-500/5" : "border-emerald-500/20 bg-emerald-500/5"}
        />
        <MetricCard
          title="Monthly Nut"
          value={`$${monthlyBills.toFixed(2)}`}
          icon={<TrendingUp className="w-5 h-5" />}
          subtitle="Strict Bills"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Strict Envelopes Status */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">Strict Envelopes Status</CardTitle>
              <Link href="/envelopes" className="text-sm text-primary hover:text-primary/80 flex items-center transition-colors">
                Manage <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {strictEnvelopes.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No strict envelopes set up yet. Go to Envelopes to add bills.
                  </div>
                ) : (
                  strictEnvelopes.map(env => {
                    const progress = (Number(env.currentBalance) / Number(env.targetAmount)) * 100;
                    const isFullyFunded = progress >= 100;
                    
                    return (
                      <div key={env.id} className="group">
                        <div className="flex justify-between items-end mb-2">
                          <div>
                            <span className="font-medium text-foreground">{env.name}</span>
                            {env.dueDate && (
                              <span className="text-xs text-muted-foreground ml-2">Due the {env.dueDate}th</span>
                            )}
                          </div>
                          <div className="text-right">
                            <span className={cn(
                              "font-mono font-bold",
                              isFullyFunded ? "text-emerald-400" : "text-amber-400"
                            )}>
                              ${Number(env.currentBalance).toFixed(2)}
                            </span>
                            <span className="text-muted-foreground text-xs ml-1">
                              / ${Number(env.targetAmount).toFixed(2)}
                            </span>
                          </div>
                        </div>
                        <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full rounded-full transition-all duration-500",
                              isFullyFunded ? "bg-emerald-500" : "bg-amber-500"
                            )}
                            style={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="bg-card/50 border-border/50">
            <CardHeader>
              <CardTitle className="text-lg font-medium">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.length === 0 ? (
                  <div className="text-muted-foreground text-sm">No recent transactions found.</div>
                ) : (
                  recentTransactions.map(tx => (
                    <div key={tx.id} className="flex justify-between items-center py-2 border-b border-border/40 last:border-0">
                      <div>
                        <p className="font-medium text-sm">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">{format(new Date(tx.date || new Date()), "MMM dd, yyyy")}</p>
                      </div>
                      <span className={cn(
                        "font-mono font-medium",
                        tx.type === 'income' ? "text-emerald-400" : "text-white"
                      )}>
                        {tx.type === 'income' ? '+' : '-'}${Math.abs(Number(tx.amount)).toFixed(2)}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Debt Progress Sidebar */}
        <div className="space-y-6">
          <Card className="bg-gradient-to-br from-red-950/20 to-card border-red-900/20 border">
            <CardHeader>
              <CardTitle className="text-red-200">Debt Crusher</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {debts?.map(debt => (
                <div key={debt.id} className="bg-black/20 p-4 rounded-xl border border-red-900/10">
                  <div className="flex justify-between mb-1">
                    <span className="font-medium text-red-100">{debt.name}</span>
                    <span className="text-red-200 font-mono">${Number(debt.totalAmount).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-red-300/60 mb-3">
                    <span>{Number(debt.interestRate)}% APR</span>
                    <span>Min: ${Number(debt.minimumPayment)}</span>
                  </div>
                  <Link href="/debts">
                    <Button size="sm" variant="outline" className="w-full border-red-900/30 text-red-200 hover:bg-red-950 hover:text-red-100">
                      View Payoff Plan
                    </Button>
                  </Link>
                </div>
              ))}
              {debts?.length === 0 && (
                <div className="text-center py-4 text-emerald-400">
                  <ShieldCheck className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>Debt Free!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
