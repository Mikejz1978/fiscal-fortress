import { Layout } from "@/components/Layout";
import { useAccounts, useCreateAccount } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Wallet, PiggyBank, CreditCard, Building } from "lucide-react";
import { useState } from "react";
import { insertAccountSchema } from "@shared/schema";

const formSchema = insertAccountSchema.extend({
  balance: z.coerce.number(),
});

export default function Accounts() {
  const { data: accounts, isLoading } = useAccounts();
  const createAccount = useCreateAccount();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      type: "checking",
      balance: 0,
      isMain: false,
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // Ensure userId is handled by backend or auth context - for now just passing through
    // In a real app, userId comes from session on backend
    const submissionData = { ...data, userId: "current" }; 
    createAccount.mutate(submissionData as any, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'savings': return <PiggyBank className="w-6 h-6 text-emerald-400" />;
      case 'credit': return <CreditCard className="w-6 h-6 text-red-400" />;
      default: return <Wallet className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Accounts</h2>
          <p className="text-muted-foreground">Manage your money silos.</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="w-5 h-5 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Add New Account</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Account Name</Label>
                <Input id="name" {...form.register("name")} placeholder="e.g. Bills Checking" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select onValueChange={(val) => form.setValue("type", val)} defaultValue="checking">
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="checking">Checking</SelectItem>
                    <SelectItem value="savings">Savings</SelectItem>
                    <SelectItem value="credit">Credit Card</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="balance">Current Balance</Label>
                <Input id="balance" type="number" step="0.01" {...form.register("balance")} />
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <input 
                  type="checkbox" 
                  id="isMain" 
                  className="rounded border-gray-600 bg-gray-700 text-primary focus:ring-primary"
                  {...form.register("isMain")} 
                />
                <Label htmlFor="isMain">This is my main income account</Label>
              </div>

              <div className="pt-4">
                <Button type="submit" className="w-full" disabled={createAccount.isPending}>
                  {createAccount.isPending ? "Creating..." : "Create Account"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accounts?.map((account) => (
          <Card key={account.id} className="bg-card border-border hover:border-primary/50 transition-colors group">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium flex items-center gap-3">
                <div className="p-2 bg-secondary rounded-lg group-hover:bg-primary/10 transition-colors">
                  {getIcon(account.type)}
                </div>
                {account.name}
              </CardTitle>
              {account.isMain && (
                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-full font-medium">Main</span>
              )}
            </CardHeader>
            <CardContent>
              <div className="mt-2">
                <span className="text-3xl font-display font-bold">${Number(account.balance).toFixed(2)}</span>
                <p className="text-xs text-muted-foreground mt-1 capitalize">{account.type} Account</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  );
}
