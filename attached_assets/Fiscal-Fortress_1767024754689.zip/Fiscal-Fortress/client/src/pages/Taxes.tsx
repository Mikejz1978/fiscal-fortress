import { Layout } from "@/components/Layout";
import { useTaxes, useCreateTaxEntry } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Receipt, Landmark } from "lucide-react";
import { useState } from "react";
import { insertTaxEntrySchema } from "@shared/schema";
import { format } from "date-fns";

const formSchema = insertTaxEntrySchema.extend({
  amount: z.coerce.number(),
});

export default function Taxes() {
  const { data: taxEntries, isLoading } = useTaxes();
  const createEntry = useCreateTaxEntry();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
      amount: 0,
      type: "write_off",
      category: "business_expense",
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    const submissionData = { ...data, userId: "current" }; 
    createEntry.mutate(submissionData as any, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  const totalWriteOffs = taxEntries
    ?.filter(t => t.type === 'write_off')
    .reduce((sum, t) => sum + Number(t.amount), 0) || 0;

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-1">Tax Vault</h2>
          <p className="text-muted-foreground">Track write-offs and estimate liabilities.</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Plus className="w-5 h-5 mr-2" />
              Log Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Log Tax Entry</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input id="description" {...form.register("description")} placeholder="e.g. Business Laptop" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" type="number" step="0.01" {...form.register("amount")} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Type</Label>
                  <Select onValueChange={(val) => form.setValue("type", val)} defaultValue="write_off">
                    <SelectTrigger>
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="write_off">Write Off</SelectItem>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="payment">Tax Payment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select onValueChange={(val) => form.setValue("category", val)} defaultValue="business_expense">
                    <SelectTrigger>
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="business_expense">Business Exp</SelectItem>
                      <SelectItem value="charity">Charity</SelectItem>
                      <SelectItem value="medical">Medical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4">
                <Button type="submit" className="w-full" disabled={createEntry.isPending}>
                  {createEntry.isPending ? "Logging..." : "Log Entry"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-card/50 border-border">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Total Write-Offs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display font-bold text-emerald-400">${totalWriteOffs.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Deductible expenses this year</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Tax Log</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {taxEntries?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No entries found.</div>
            ) : (
              taxEntries?.map((entry) => (
                <div key={entry.id} className="flex justify-between items-center py-3 border-b border-border/40 last:border-0 hover:bg-secondary/20 px-2 rounded-lg transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-secondary rounded-lg">
                      {entry.type === 'write_off' ? <Receipt className="w-5 h-5 text-emerald-400" /> : <Landmark className="w-5 h-5 text-blue-400" />}
                    </div>
                    <div>
                      <p className="font-medium">{entry.description}</p>
                      <p className="text-xs text-muted-foreground flex gap-2">
                        <span>{format(new Date(entry.date || new Date()), "MMM dd, yyyy")}</span>
                        <span className="capitalize px-1.5 py-0.5 rounded-full bg-secondary text-xs">{entry.category?.replace('_', ' ')}</span>
                      </p>
                    </div>
                  </div>
                  <span className="font-mono font-bold">${Number(entry.amount).toFixed(2)}</span>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </Layout>
  );
}
