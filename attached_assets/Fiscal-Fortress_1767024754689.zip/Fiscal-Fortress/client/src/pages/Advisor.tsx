import { Layout } from "@/components/Layout";
import { useAdvisorChat } from "@/hooks/use-financials";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bot, User, Send, ShieldCheck } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function Advisor() {
  const { mutate: sendMessage, isPending } = useAdvisorChat();
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'I am your Financial Sentinel. Ask me before you spend. "Can I buy these $200 headphones?"' }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMsg = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");

    sendMessage(input, {
      onSuccess: (data) => {
        setMessages(prev => [...prev, { role: 'assistant', content: data.response }]);
      },
      onError: () => {
        setMessages(prev => [...prev, { role: 'assistant', content: "Secure connection lost. I cannot verify this transaction right now." }]);
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
        <div className="mb-6 flex items-center gap-3">
          <div className="p-3 bg-primary/20 rounded-xl">
            <ShieldCheck className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-display font-bold text-white">Financial Advisor</h2>
            <p className="text-muted-foreground">Real-time spending authorization.</p>
          </div>
        </div>

        <div className="flex-1 bg-card/50 border border-border rounded-2xl flex flex-col overflow-hidden backdrop-blur-sm shadow-xl">
          <ScrollArea className="flex-1 p-6" viewportRef={scrollRef}>
            <div className="space-y-6">
              {messages.map((msg, idx) => (
                <div key={idx} className={cn("flex gap-4", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
                  <Avatar className={cn(
                    "w-10 h-10 border",
                    msg.role === 'assistant' ? "border-primary/50 bg-primary/20" : "border-white/20 bg-secondary"
                  )}>
                    <AvatarFallback className="text-foreground">
                      {msg.role === 'assistant' ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={cn(
                    "max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed",
                    msg.role === 'assistant' 
                      ? "bg-secondary text-foreground rounded-tl-none border border-border" 
                      : "bg-primary text-primary-foreground rounded-tr-none shadow-lg shadow-primary/20"
                  )}>
                    {msg.content}
                  </div>
                </div>
              ))}
              {isPending && (
                <div className="flex gap-4">
                  <Avatar className="w-10 h-10 border border-primary/50 bg-primary/20">
                    <AvatarFallback><Bot className="w-5 h-5" /></AvatarFallback>
                  </Avatar>
                  <div className="bg-secondary p-4 rounded-2xl rounded-tl-none border border-border flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <span className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100" />
                    <span className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-4 bg-card border-t border-border">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Can I afford a new iPad?..."
                className="flex-1 bg-secondary/50 border-border focus:ring-primary"
                disabled={isPending}
              />
              <Button onClick={handleSend} disabled={isPending || !input.trim()} size="icon" className="bg-primary hover:bg-primary/90">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
