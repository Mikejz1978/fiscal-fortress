import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// ACCOUNTS
export function useAccounts() {
  return useQuery({
    queryKey: [api.accounts.list.path],
    queryFn: async () => {
      const res = await fetch(api.accounts.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch accounts");
      return api.accounts.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateAccount() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.accounts.create.input>) => {
      // Coerce balance to string if it's a number (for numeric field in DB)
      const payload = { ...data, balance: String(data.balance) };
      const res = await fetch(api.accounts.create.path, {
        method: api.accounts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create account");
      return api.accounts.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.accounts.list.path] }),
  });
}

// ENVELOPES
export function useEnvelopes() {
  return useQuery({
    queryKey: [api.envelopes.list.path],
    queryFn: async () => {
      const res = await fetch(api.envelopes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch envelopes");
      return api.envelopes.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateEnvelope() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.envelopes.create.input>) => {
      const payload = { 
        ...data, 
        targetAmount: String(data.targetAmount),
        currentBalance: String(data.currentBalance || "0") 
      };
      const res = await fetch(api.envelopes.create.path, {
        method: api.envelopes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create envelope");
      return api.envelopes.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.envelopes.list.path] }),
  });
}

export function useUpdateEnvelope() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<z.infer<typeof api.envelopes.create.input>>) => {
      const url = buildUrl(api.envelopes.update.path, { id });
      const res = await fetch(url, {
        method: api.envelopes.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update envelope");
      return api.envelopes.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.envelopes.list.path] }),
  });
}

// TRANSACTIONS
export function useTransactions() {
  return useQuery({
    queryKey: [api.transactions.list.path],
    queryFn: async () => {
      const res = await fetch(api.transactions.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return api.transactions.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateTransaction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.transactions.create.input>) => {
      const payload = { ...data, amount: String(data.amount) };
      const res = await fetch(api.transactions.create.path, {
        method: api.transactions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create transaction");
      return api.transactions.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.accounts.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.envelopes.list.path] });
    },
  });
}

// DEBTS
export function useDebts() {
  return useQuery({
    queryKey: [api.debts.list.path],
    queryFn: async () => {
      const res = await fetch(api.debts.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch debts");
      return api.debts.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateDebt() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.debts.create.input>) => {
      const payload = {
        ...data,
        totalAmount: String(data.totalAmount),
        interestRate: String(data.interestRate),
        minimumPayment: String(data.minimumPayment)
      };
      const res = await fetch(api.debts.create.path, {
        method: api.debts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create debt");
      return api.debts.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.debts.list.path] }),
  });
}

// TAXES
export function useTaxes() {
  return useQuery({
    queryKey: [api.taxes.list.path],
    queryFn: async () => {
      const res = await fetch(api.taxes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch taxes");
      return api.taxes.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateTaxEntry() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.taxes.create.input>) => {
      const payload = { ...data, amount: String(data.amount) };
      const res = await fetch(api.taxes.create.path, {
        method: api.taxes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create tax entry");
      return api.taxes.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.taxes.list.path] }),
  });
}

// ADVISOR
export function useAdvisorChat() {
  return useMutation({
    mutationFn: async (message: string) => {
      const res = await fetch(api.advisor.chat.path, {
        method: api.advisor.chat.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get advisor response");
      return api.advisor.chat.responses[200].parse(await res.json());
    },
  });
}
