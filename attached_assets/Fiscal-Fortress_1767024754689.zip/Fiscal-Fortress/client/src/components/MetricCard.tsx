import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight, TrendingUp } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string;
  subtitle?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  icon?: ReactNode;
  className?: string;
  delay?: number;
}

export function MetricCard({ 
  title, 
  value, 
  subtitle, 
  trend, 
  trendValue, 
  icon, 
  className 
}: MetricCardProps) {
  return (
    <div className={cn(
      "bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6",
      "hover:border-primary/20 hover:bg-card/80 transition-all duration-300",
      "shadow-lg shadow-black/5",
      className
    )}>
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-muted-foreground font-medium text-sm tracking-wide uppercase">{title}</h3>
        {icon && <div className="text-primary/80">{icon}</div>}
      </div>
      
      <div className="flex items-baseline gap-2 mb-1">
        <span className="text-3xl font-display font-bold text-foreground tracking-tight">{value}</span>
      </div>
      
      {(subtitle || trend) && (
        <div className="flex items-center gap-2 text-sm mt-2">
          {trend === "up" && (
            <span className="flex items-center text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full font-medium text-xs">
              <ArrowUpRight className="w-3 h-3 mr-1" />
              {trendValue}
            </span>
          )}
          {trend === "down" && (
            <span className="flex items-center text-rose-400 bg-rose-400/10 px-2 py-0.5 rounded-full font-medium text-xs">
              <ArrowDownRight className="w-3 h-3 mr-1" />
              {trendValue}
            </span>
          )}
          {subtitle && <span className="text-muted-foreground">{subtitle}</span>}
        </div>
      )}
    </div>
  );
}
