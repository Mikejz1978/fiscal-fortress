import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Wallet, 
  PiggyBank, 
  CreditCard, 
  Receipt, 
  LogOut, 
  Bot, 
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Dashboard", icon: <LayoutDashboard className="w-5 h-5" /> },
    { href: "/accounts", label: "Accounts", icon: <Wallet className="w-5 h-5" /> },
    { href: "/envelopes", label: "Envelopes", icon: <PiggyBank className="w-5 h-5" /> },
    { href: "/debts", label: "Debt Crusher", icon: <CreditCard className="w-5 h-5" /> },
    { href: "/taxes", label: "Tax Vault", icon: <Receipt className="w-5 h-5" /> },
    { href: "/advisor", label: "AI Advisor", icon: <Bot className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex bg-background text-foreground selection:bg-primary/20">
      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-black/80 z-40 md:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed md:sticky top-0 left-0 z-50 h-screen w-72 bg-card/95 backdrop-blur-xl border-r border-border/40 flex flex-col transition-transform duration-300 md:translate-x-0",
        mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 border-b border-border/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <span className="text-white font-bold text-xl">S</span>
            </div>
            <h1 className="font-display font-bold text-xl tracking-tight text-white">Shadow Ledger</h1>
          </div>
          <button className="md:hidden text-muted-foreground" onClick={() => setMobileMenuOpen(false)}>
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group font-medium",
              location === item.href 
                ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" 
                : "text-muted-foreground hover:bg-white/5 hover:text-white"
            )}>
              <span className={cn(
                "transition-colors",
                location === item.href ? "text-primary" : "text-muted-foreground group-hover:text-white"
              )}>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-border/40">
          <div className="flex items-center gap-3 px-4 py-3 mb-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.firstName || 'User'}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-3 text-muted-foreground hover:text-red-400 hover:bg-red-400/10"
            onClick={() => logout()}
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden h-16 border-b border-border/40 flex items-center px-4 bg-card/80 backdrop-blur-md sticky top-0 z-30">
          <button onClick={() => setMobileMenuOpen(true)} className="text-foreground p-2">
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-bold ml-2">Shadow Ledger</span>
        </header>
        
        <div className="flex-1 p-4 md:p-8 lg:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500 slide-in-from-bottom-2">
          {children}
        </div>
      </main>
    </div>
  );
}
